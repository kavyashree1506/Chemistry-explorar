import streamlit as st

st.set_page_config(
    page_title="Chemistry Explorer",
    page_icon="🧪",
    layout="wide",
    initial_sidebar_state="collapsed",
)

COMPOUNDS = {
    "Acetic Acid": {
        "aka": "Ethanoic acid",
        "formula": "CH₃COOH",
        "molecular_formula": "C₂H₄O₂",
        "mass": "60.05 g/mol",
        "type": "Carboxylic acid",
        "smiles": "CC(=O)O",
        "structure_url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/acetic%20acid/PNG",
        "pubchem": "https://pubchem.ncbi.nlm.nih.gov/compound/176",
        "properties": [
            "Colourless liquid with a characteristic vinegar-like odour.",
            "Mixes completely with water.",
            "A weak acid in water; concentrated (glacial) acetic acid is corrosive.",
            "Pure acetic acid freezes at about 16.6 °C."
        ],
        "preparation": [
            "Biological route: acetic-acid bacteria oxidise ethanol to acetic acid during vinegar production.",
            "Industrial route: methanol is carbonylated with carbon monoxide using a catalyst."
        ],
        "uses": [
            "Dilute solutions are the main acid in vinegar and are used in food preparation.",
            "Feedstock for acetate esters, polymers, and other industrial chemicals.",
            "Used in controlled laboratory and manufacturing processes."
        ],
        "safety": [
            "Concentrated acetic acid can cause serious skin and eye burns; vapour may irritate the respiratory tract.",
            "Use appropriate eye protection, chemical-resistant gloves, and good ventilation in a supervised lab.",
            "Do not taste or directly sniff laboratory chemicals. Follow the label and safety data sheet."
        ],
        "summary": "The familiar acid in vinegar; the pure concentrated chemical is much more hazardous than household vinegar."
    },
    "Phenol": {
        "aka": "Hydroxybenzene",
        "formula": "C₆H₅OH",
        "molecular_formula": "C₆H₆O",
        "mass": "94.11 g/mol",
        "type": "Aromatic compound / weak acid",
        "smiles": "C1=CC=C(C=C1)O",
        "structure_url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/phenol/PNG",
        "pubchem": "https://pubchem.ncbi.nlm.nih.gov/compound/996",
        "properties": [
            "Pure phenol is a colourless-to-white crystalline solid near room temperature; it can liquefy in a warm room.",
            "Has limited solubility in water and is soluble in many organic solvents.",
            "The –OH group is attached directly to an aromatic benzene ring.",
            "It is a weak acid and is significantly more hazardous than many common household chemicals."
        ],
        "preparation": [
            "Major industrial route: the cumene process, in which cumene is oxidised to an intermediate that is cleaved to phenol and acetone.",
            "This is an industrial process, not a suitable home or classroom preparation."
        ],
        "uses": [
            "Manufacture of phenolic resins, adhesives, and other polymers.",
            "Starting material for various industrial chemicals and pharmaceuticals.",
            "Historical antiseptic use; concentrated phenol is not safe for casual disinfectant use."
        ],
        "safety": [
            "Phenol is toxic and corrosive and can be absorbed through skin, causing serious injury.",
            "Avoid all skin contact and inhalation; handling requires suitable protective equipment and a trained supervisor.",
            "In a suspected exposure, alert the lab supervisor and follow the institution's emergency procedures immediately."
        ],
        "summary": "An aromatic molecule with an –OH group directly attached to a benzene ring; it is an important industrial feedstock but highly hazardous."
    },
    "Aspirin": {
        "aka": "Acetylsalicylic acid",
        "formula": "C₉H₈O₄",
        "molecular_formula": "C₉H₈O₄",
        "mass": "180.16 g/mol",
        "type": "Aromatic carboxylic acid ester",
        "smiles": "CC(=O)OC1=CC=CC=C1C(=O)O",
        "structure_url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/aspirin/PNG",
        "pubchem": "https://pubchem.ncbi.nlm.nih.gov/compound/2244",
        "properties": [
            "Usually a white crystalline solid.",
            "Contains both a carboxylic acid group and an ester group.",
            "Only slightly soluble in water; it can hydrolyse to salicylic acid and acetic acid, especially under moist or alkaline conditions.",
            "Molar mass is approximately 180.16 g/mol."
        ],
        "preparation": [
            "In chemistry education, aspirin is described as being formed by acetylating salicylic acid with an acetylating agent such as acetic anhydride, with an acid catalyst.",
            "This is a supervised laboratory or industrial synthesis; this learning app intentionally does not provide an experimental recipe."
        ],
        "uses": [
            "A medicine used for pain relief, fever reduction, and inflammation.",
            "At selected low doses, clinicians may prescribe it to reduce platelet aggregation in certain patients.",
            "It should be used only according to appropriate medical advice and product directions."
        ],
        "safety": [
            "Aspirin can irritate the stomach and increase bleeding risk; allergic reactions can occur.",
            "Children and teenagers should not take aspirin for viral illnesses unless specifically directed by a healthcare professional because of the risk of Reye syndrome.",
            "Do not use this learning app to decide a dose or replace advice from a pharmacist or clinician."
        ],
        "summary": "A widely known medicine that combines an aromatic ring, an ester group, and a carboxylic acid group."
    },
}

QUIZ = [
    {
        "q": "Which compound is the main acid in vinegar?",
        "options": ["Phenol", "Acetic acid", "Aspirin", "Ethanol"],
        "answer": "Acetic acid",
        "why": "Vinegar contains a dilute aqueous solution of acetic acid."
    },
    {
        "q": "Which compound has an –OH group attached directly to a benzene ring?",
        "options": ["Aspirin", "Acetic acid", "Phenol", "Sodium chloride"],
        "answer": "Phenol",
        "why": "Phenol is hydroxybenzene: its hydroxyl group is bonded directly to the aromatic ring."
    },
    {
        "q": "What is the molecular formula of aspirin?",
        "options": ["C₂H₄O₂", "C₆H₆O", "C₉H₈O₄", "C₈H₁₀N₄O₂"],
        "answer": "C₉H₈O₄",
        "why": "Aspirin (acetylsalicylic acid) has molecular formula C₉H₈O₄."
    },
    {
        "q": "Which statement about concentrated acetic acid is correct?",
        "options": [
            "It is always harmless because vinegar is edible.",
            "It can cause serious skin and eye burns.",
            "It is a neutral salt.",
            "It cannot irritate the respiratory tract."
        ],
        "answer": "It can cause serious skin and eye burns.",
        "why": "Concentrated acetic acid is corrosive; hazards depend strongly on concentration."
    },
    {
        "q": "Which industrial process is a major route for producing phenol?",
        "options": ["Cumene process", "Haber process", "Contact process", "Solvay process"],
        "answer": "Cumene process",
        "why": "The cumene process is a major industrial route that produces phenol and acetone."
    },
    {
        "q": "Which functional groups are present in aspirin?",
        "options": [
            "Only an alcohol group",
            "A carboxylic acid and an ester",
            "An aldehyde and an amine",
            "Only a ketone"
        ],
        "answer": "A carboxylic acid and an ester",
        "why": "Aspirin contains a –COOH carboxylic acid group and an ester linkage."
    },
]

# Styling: restrained CSS for a responsive, mobile-friendly layout.
st.markdown("""
<style>
:root { color-scheme: light; }
.block-container { padding-top: 1.2rem; padding-bottom: 2.5rem; max-width: 1150px; }
.hero {
  padding: 1.5rem 1.6rem; border-radius: 22px;
  background: linear-gradient(120deg, #f1edff 0%, #eef8ff 100%);
  border: 1px solid #e1dcff; margin-bottom: 1.2rem;
}
.hero h1 { margin: 0; color: #22264e; font-size: clamp(1.8rem, 4vw, 2.7rem); }
.hero p { color: #4d5577; font-size: 1.05rem; margin-bottom: 0; }
.compound-card {
  border: 1px solid #e4e7f4; border-radius: 18px; padding: 1rem;
  background: #ffffff; min-height: 170px; box-shadow: 0 3px 14px rgba(40,50,100,.04);
}
.formula { font-size: 1.25rem; font-weight: 700; color: #5541c8; }
.pill {
  display: inline-block; border-radius: 999px; padding: .22rem .65rem;
  background: #f0edff; color: #5541c8; font-size: .78rem; font-weight: 600;
}
.small-muted { color: #67708e; font-size: .9rem; }
.warning-box {
  padding: .85rem 1rem; border-radius: 12px; background: #fff5e9;
  border: 1px solid #ffdfb8; color: #784700;
}
footer { visibility: hidden; }
@media (max-width: 700px) {
  .block-container { padding-left: 1rem; padding-right: 1rem; }
  .hero { padding: 1.1rem; }
}
</style>
""", unsafe_allow_html=True)

if "page" not in st.session_state:
    st.session_state.page = "Home"
if "selected_compound" not in st.session_state:
    st.session_state.selected_compound = "Acetic Acid"
if "quiz_index" not in st.session_state:
    st.session_state.quiz_index = 0
if "quiz_score" not in st.session_state:
    st.session_state.quiz_score = 0
if "quiz_answered" not in st.session_state:
    st.session_state.quiz_answered = {}
if "quiz_finished" not in st.session_state:
    st.session_state.quiz_finished = False

def go_to_compound(name):
    st.session_state.selected_compound = name
    st.session_state.page = "Compound details"

# Header / functional navigation
header_left, header_right = st.columns([2.2, 3])
with header_left:
    st.markdown("## 🧪 Chemistry Explorer")
    st.caption("Learn · Explore · Build your chemical knowledge")
with header_right:
    nav_cols = st.columns(4)
    nav_items = [("Home", "🏠 Home"), ("Compounds", "🧬 Compounds"), ("Quiz", "📝 Quiz"), ("About", "ℹ️ About")]
    for col, (page_name, label) in zip(nav_cols, nav_items):
        with col:
            if st.button(label, key=f"nav_{page_name}", use_container_width=True):
                st.session_state.page = page_name
                st.rerun()

st.markdown("""
<div class="hero">
  <h1>Explore chemistry, one molecule at a time.</h1>
  <p>Meet acetic acid, phenol, and aspirin through their structures, properties, preparation, uses, and safety.</p>
</div>
""", unsafe_allow_html=True)

# Search is available throughout the app.
search_col, search_btn_col = st.columns([5, 1])
with search_col:
    search_text = st.text_input("🔎 Search compounds", placeholder="Try acetic acid, phenol, aspirin, formula, or use…", label_visibility="collapsed", key="compound_search")
with search_btn_col:
    search_clicked = st.button("Search", use_container_width=True)

def matches(name, data, term):
    haystack = " ".join([
        name, data["aka"], data["formula"], data["molecular_formula"], data["type"],
        data["summary"], " ".join(data["properties"]), " ".join(data["uses"])
    ]).lower()
    return term.lower() in haystack

if search_clicked:
    term = search_text.strip()
    if term:
        found = [name for name, data in COMPOUNDS.items() if matches(name, data, term)]
        if found:
            st.success("Found: " + ", ".join(found))
            if len(found) == 1:
                go_to_compound(found[0])
        else:
            st.warning("No exact match found. Try a compound name, formula, or keyword such as 'medicine' or 'acid'.")
    else:
        st.info("Type a compound name, formula, or keyword to search.")

if st.session_state.page in ("Home", "Compounds"):
    st.subheader("Featured compounds" if st.session_state.page == "Home" else "All compounds")
    names = list(COMPOUNDS.keys())
    term = search_text.strip()
    if term and not search_clicked:
        names = [name for name, data in COMPOUNDS.items() if matches(name, data, term)]
    if not names:
        st.info("No compounds match that search yet.")
    else:
        cols = st.columns(len(names))
        for col, name in zip(cols, names):
            data = COMPOUNDS[name]
            with col:
                st.markdown(f"""
                <div class="compound-card">
                  <span class="pill">{data['type']}</span>
                  <h3 style="margin:.75rem 0 .2rem">{name}</h3>
                  <div class="small-muted">{data['aka']}</div>
                  <p class="formula">{data['formula']}</p>
                  <div class="small-muted">Molar mass: {data['mass']}</div>
                  <p>{data['summary']}</p>
                </div>
                """, unsafe_allow_html=True)
                if st.button(f"View {name}", key=f"view_{name}", use_container_width=True):
                    go_to_compound(name)
                    st.rerun()

    st.markdown("---")
    st.subheader("Quick quiz")
    st.write("Check what you remember with a short, self-marking quiz.")
    if st.button("Start the quiz →", type="primary"):
        st.session_state.page = "Quiz"
        st.rerun()

elif st.session_state.page == "Compound details":
    name = st.session_state.selected_compound
    data = COMPOUNDS[name]
    st.markdown(f"## {name}")
    st.caption(f"{data['aka']} · {data['type']}")
    f1, f2, f3 = st.columns(3)
    f1.metric("Chemical formula", data["formula"])
    f2.metric("Molecular formula", data["molecular_formula"])
    f3.metric("Molar mass", data["mass"])

    left, right = st.columns([1, 1.2])
    with left:
        st.markdown("### Molecular structure")
        st.image(data["structure_url"], caption=f"PubChem structure image · SMILES: {data['smiles']}", use_container_width=True)
        st.caption("Structure image is loaded from PubChem. If it does not appear, use the PubChem reference link below.")
        st.link_button("Open PubChem record ↗", data["pubchem"], use_container_width=True)
    with right:
        st.markdown("### Properties")
        for item in data["properties"]:
            st.markdown(f"- {item}")
        st.markdown("### Preparation")
        for item in data["preparation"]:
            st.markdown(f"- {item}")
        st.markdown("### Uses")
        for item in data["uses"]:
            st.markdown(f"- {item}")
    st.markdown("### Safety precautions")
    st.markdown('<div class="warning-box"><b>Safety first:</b> Read all precautions before handling any chemical.</div>', unsafe_allow_html=True)
    for item in data["safety"]:
        st.markdown(f"- {item}")
    st.markdown("---")
    prev = st.columns([1, 1, 1])
    for col, other in zip(prev, COMPOUNDS.keys()):
        with col:
            if st.button(f"Explore {other}", key=f"switch_{other}", use_container_width=True):
                go_to_compound(other)
                st.rerun()

elif st.session_state.page == "Quiz":
    st.subheader("📝 Chemistry Quick Quiz")
    st.write("Answer each question, submit to see feedback, and track your score.")
    if st.session_state.quiz_finished:
        st.success(f"Quiz complete! Your score: {st.session_state.quiz_score} / {len(QUIZ)}")
        if st.button("Try again", type="primary"):
            st.session_state.quiz_index = 0
            st.session_state.quiz_score = 0
            st.session_state.quiz_answered = {}
            st.session_state.quiz_finished = False
            st.rerun()
    else:
        idx = st.session_state.quiz_index
        question = QUIZ[idx]
        st.progress((idx + 1) / len(QUIZ), text=f"Question {idx + 1} of {len(QUIZ)}")
        st.markdown(f"### {question['q']}")
        selected = st.radio("Choose one answer", question["options"], key=f"quiz_choice_{idx}", label_visibility="collapsed")
        if idx not in st.session_state.quiz_answered:
            if st.button("Check answer", type="primary"):
                is_correct = selected == question["answer"]
                st.session_state.quiz_answered[idx] = {"selected": selected, "correct": is_correct}
                if is_correct:
                    st.session_state.quiz_score += 1
                st.rerun()
        else:
            result = st.session_state.quiz_answered[idx]
            if result["correct"]:
                st.success("Correct! " + question["why"])
            else:
                st.error(f"Not quite. Correct answer: {question['answer']}. {question['why']}")
            if st.button("Next question →", type="primary"):
                if idx + 1 < len(QUIZ):
                    st.session_state.quiz_index += 1
                else:
                    st.session_state.quiz_finished = True
                st.rerun()
        st.caption(f"Current score: {st.session_state.quiz_score} / {len(st.session_state.quiz_answered)} answered")

elif st.session_state.page == "About":
    st.subheader("About Chemistry Explorer")
    st.write("Chemistry Explorer is a beginner-friendly learning app for three organic compounds: acetic acid, phenol, and aspirin.")
    st.markdown("""
    **What you can do**
    - Search by compound name, formula, class, or related keyword.
    - Open a compound card to view its formula, molecular structure, properties, preparation overview, uses, and safety notes.
    - Complete the quiz and see your score.

    **Scientific note:** Preparation descriptions are conceptual summaries, not experimental instructions. Use a course textbook, instructor guidance, and current safety data sheets for formal laboratory work.
    """)
    st.markdown("### Sources")
    st.markdown("- [PubChem: Acetic acid](https://pubchem.ncbi.nlm.nih.gov/compound/176)")
    st.markdown("- [PubChem: Phenol](https://pubchem.ncbi.nlm.nih.gov/compound/996)")
    st.markdown("- [PubChem: Aspirin](https://pubchem.ncbi.nlm.nih.gov/compound/2244)")
    st.markdown("- [NIOSH Pocket Guide: Acetic acid](https://www.cdc.gov/niosh/npg/npgd0002.html)")

st.markdown("---")
st.caption("Chemistry Explorer · Learning resource only · Always follow laboratory safety rules and qualified medical advice.")
