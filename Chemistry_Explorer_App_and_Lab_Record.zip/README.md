# Chemistry Explorer

A beginner-friendly, responsive Streamlit app about acetic acid, phenol, and aspirin.

## Features
- Search by compound name, formula, class, and selected related keywords
- Compound cards and functional detail navigation
- Formula, molecular mass, PubChem structure image, SMILES, properties, preparation overview, uses, and safety precautions
- Six-question quiz with feedback, scoring, next-question navigation, and restart
- About page with scientific references

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `streamlit run app.py`
5. Open the local URL Streamlit prints.

## Deploy online
Upload `app.py` and `requirements.txt` to a GitHub repository, then create an app in Streamlit Community Cloud using that repository.

Structure images are loaded from PubChem's PUG REST service, so internet access is needed for those images.
